# Purpose

演示[Sentinel](https://github.com/alibaba/Sentinel)如何通过Apollo配置中心实现中心化流控规则配置

# Instructions

- [基于Apollo配置中心的Sentinel流控规则配置实战（一）](https://mp.weixin.qq.com/s?__biz=MzA4NzA0NjAzOQ==&mid=2257484007&idx=1&sn=26e228c98d0743df098969be4a86f106&chksm=9345ba1fa43233090885ba37b601ed9f28e278c6585b5c73c5e6d801615240defd48786a79f5&token=159781885&lang=zh_CN&scene=21#wechat_redirect)
- [基于Apollo配置中心的Sentinel流控规则配置实战（二） ](https://mp.weixin.qq.com/s?__biz=MzA4NzA0NjAzOQ==&mid=2257484017&idx=1&sn=cce834ad61e172a439f86e188e243144&chksm=9345ba09a432331fe5652240c6bebe50d687e58e7a82e1fcd2911a4b43f14c86a5c426c1c731&scene=0&xtrack=1#rd)
