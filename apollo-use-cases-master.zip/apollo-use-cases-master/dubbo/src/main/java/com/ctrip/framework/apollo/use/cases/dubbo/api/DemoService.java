package com.ctrip.framework.apollo.use.cases.dubbo.api;

public interface DemoService {

  String sayHello(String name);
}
