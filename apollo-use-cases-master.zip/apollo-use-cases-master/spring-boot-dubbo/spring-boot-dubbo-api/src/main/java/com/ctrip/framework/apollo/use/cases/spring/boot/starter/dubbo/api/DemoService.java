package com.ctrip.framework.apollo.use.cases.spring.boot.starter.dubbo.api;

public interface DemoService {

  String sayHello(String name);
}
